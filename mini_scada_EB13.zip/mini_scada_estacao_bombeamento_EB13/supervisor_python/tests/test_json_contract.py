"""Testes do contrato JSON e parametros da assinatura EB-13.

Roda com: pytest tests/

Testamos tres coisas:
1. Que o contrato minimo de uma leitura tem todos os campos obrigatorios
2. Que os parametros da assinatura EB-13 estao dentro dos intervalos
   permitidos pela especificacao do trabalho
3. Que o parser de pacotes do supervisor tolera linhas invalidas
   sem quebrar
"""

import io
import json
from pathlib import Path

import pytest


# ------------------------------------------------------------
# Parametros da dupla (devem bater com main.cpp)
# ------------------------------------------------------------
ID_DUPLA = 13
ESTACAO = "EB-13"
NIVEL_BAIXO = 23.0
NIVEL_ALTO = 81.0
PRESSAO_ALTA = 6.3

CAMPOS_LEITURA_OBRIGATORIOS = {"tag", "valor", "unidade", "timestamp", "status"}
CAMPOS_PACOTE_OBRIGATORIOS = {"estacao", "ciclo", "timestamp", "leituras", "bombas", "alarmes"}


# ------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------
@pytest.fixture
def pacote_valido():
    return {
        "estacao": ESTACAO,
        "ciclo": 1,
        "timestamp": "2026-06-26T10:00:00",
        "assinatura": {
            "id_dupla": ID_DUPLA,
            "nivel_baixo": NIVEL_BAIXO,
            "nivel_alto": NIVEL_ALTO,
            "pressao_alta": PRESSAO_ALTA,
        },
        "leituras": [
            {"tag": "LT-101", "tipo": "nivel", "valor": 48.0, "unidade": "%",
             "timestamp": "2026-06-26T10:00:00", "status": "OK"},
            {"tag": "PT-201", "tipo": "pressao", "valor": 3.4, "unidade": "bar",
             "timestamp": "2026-06-26T10:00:00", "status": "OK"},
        ],
        "bombas": [
            {"tag": "P-101A", "ligada": False, "bloqueada": False, "ciclos": 0},
            {"tag": "P-101B", "ligada": False, "bloqueada": False, "ciclos": 0},
        ],
        "alarmes": [],
    }


# ------------------------------------------------------------
# Testes dos parametros da assinatura
# ------------------------------------------------------------
def test_id_dupla_corresponde_as_matriculas():
    # ultimo digito de 20232ceca0275 = 5, de 20232ceca0038 = 8, soma = 13
    assert ID_DUPLA == 13


def test_estacao_segue_padrao_assinatura():
    assert ESTACAO == "EB-13"
    assert ESTACAO.startswith("EB-")


def test_nivel_baixo_dentro_do_intervalo_permitido():
    # especificacao: nivel baixo entre 20% e 35%
    assert 20.0 <= NIVEL_BAIXO <= 35.0


def test_nivel_alto_dentro_do_intervalo_permitido():
    # especificacao: nivel alto entre 75% e 90%
    assert 75.0 <= NIVEL_ALTO <= 90.0


def test_pressao_alta_dentro_do_intervalo_permitido():
    # especificacao: pressao alta entre 5.0 e 8.0 bar
    assert 5.0 <= PRESSAO_ALTA <= 8.0


def test_niveis_nao_se_sobrepoem():
    # baixo deve ser estritamente menor que alto, com folga operacional
    assert NIVEL_BAIXO < NIVEL_ALTO
    assert (NIVEL_ALTO - NIVEL_BAIXO) >= 30.0


# ------------------------------------------------------------
# Testes do contrato JSON
# ------------------------------------------------------------
def test_pacote_serializa_e_desserializa(pacote_valido):
    texto = json.dumps(pacote_valido)
    recarregado = json.loads(texto)
    assert recarregado == pacote_valido


def test_pacote_tem_todos_os_campos_obrigatorios(pacote_valido):
    faltando = CAMPOS_PACOTE_OBRIGATORIOS - set(pacote_valido.keys())
    assert not faltando, f"campos obrigatorios faltando: {faltando}"


def test_leituras_tem_todos_os_campos_obrigatorios(pacote_valido):
    for leitura in pacote_valido["leituras"]:
        faltando = CAMPOS_LEITURA_OBRIGATORIOS - set(leitura.keys())
        assert not faltando, f"leitura {leitura.get('tag')}: faltando {faltando}"


def test_assinatura_contem_parametros_da_dupla(pacote_valido):
    a = pacote_valido["assinatura"]
    assert a["id_dupla"] == ID_DUPLA
    assert a["nivel_baixo"] == NIVEL_BAIXO
    assert a["nivel_alto"] == NIVEL_ALTO
    assert a["pressao_alta"] == PRESSAO_ALTA


def test_pacote_aceita_lista_de_alarmes_vazia(pacote_valido):
    assert isinstance(pacote_valido["alarmes"], list)
    assert pacote_valido["alarmes"] == []


def test_pacote_com_alarme_critico(pacote_valido):
    pacote_valido["alarmes"].append({
        "codigo": "ALM_PRESSAO_ALTA",
        "severidade": "CRITICA",
        "mensagem": "pressao acima de 6.3 bar",
        "timestamp": "2026-06-26T10:00:05",
    })
    texto = json.dumps(pacote_valido)
    rec = json.loads(texto)
    assert rec["alarmes"][0]["codigo"] == "ALM_PRESSAO_ALTA"
    assert rec["alarmes"][0]["severidade"] in {"BAIXA", "MEDIA", "ALTA", "CRITICA"}


def test_bombas_tem_estrutura_esperada(pacote_valido):
    for bomba in pacote_valido["bombas"]:
        assert "tag" in bomba
        assert "ligada" in bomba and isinstance(bomba["ligada"], bool)
        assert "bloqueada" in bomba and isinstance(bomba["bloqueada"], bool)


# ------------------------------------------------------------
# Testes do parser do supervisor (tolerancia a falhas)
# ------------------------------------------------------------
def parse_jsonl(texto: str) -> list[dict]:
    """Replica a logica do ler_pacotes do app.py para teste isolado."""
    pacotes = []
    for linha in io.StringIO(texto):
        linha = linha.strip()
        if not linha:
            continue
        try:
            pacotes.append(json.loads(linha))
        except json.JSONDecodeError:
            continue
    return pacotes


def test_parser_ignora_linhas_em_branco():
    texto = '{"estacao":"EB-13","ciclo":1}\n\n\n{"estacao":"EB-13","ciclo":2}\n'
    assert len(parse_jsonl(texto)) == 2


def test_parser_ignora_linha_corrompida_no_meio():
    # uma linha quebrada nao pode derrubar o supervisor inteiro
    texto = (
        '{"estacao":"EB-13","ciclo":1}\n'
        'isso nao e json valido\n'
        '{"estacao":"EB-13","ciclo":2}\n'
    )
    pacotes = parse_jsonl(texto)
    assert len(pacotes) == 2
    assert pacotes[0]["ciclo"] == 1
    assert pacotes[1]["ciclo"] == 2


def test_parser_ignora_linha_truncada_no_final():
    # cenario real: o C++ esta gravando enquanto o supervisor le
    texto = '{"estacao":"EB-13","ciclo":1}\n{"estacao":"EB-13","ciclo":2,"leitur'
    pacotes = parse_jsonl(texto)
    assert len(pacotes) == 1


def test_parser_devolve_vazio_para_arquivo_vazio():
    assert parse_jsonl("") == []
    assert parse_jsonl("\n\n\n") == []


# ------------------------------------------------------------
# Teste de integracao - arquivo real em disco
# ------------------------------------------------------------
def test_le_arquivo_jsonl_real(tmp_path, pacote_valido):
    arq = tmp_path / "leituras.jsonl"
    with arq.open("w", encoding="utf-8") as fp:
        for i in range(1, 4):
            p = dict(pacote_valido, ciclo=i)
            fp.write(json.dumps(p) + "\n")

    conteudo = arq.read_text(encoding="utf-8")
    pacotes = parse_jsonl(conteudo)
    assert len(pacotes) == 3
    assert [p["ciclo"] for p in pacotes] == [1, 2, 3]
    assert all(p["estacao"] == "EB-13" for p in pacotes)
