"""Supervisor Streamlit - Mini-SCADA Estacao EB-13.

Le os pacotes JSON Lines gravados pelo dispositivo C++,
monta o painel operacional e registra comandos de atuacao
em arquivo separado para fins de auditoria.

Dupla: matriculas 20232ceca0275 e 20232ceca0038 (ID_DUPLA = 13).
"""

import json
from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st

# Caminhos relativos a raiz do projeto (pasta acima de supervisor_python/)
BASE = Path(__file__).resolve().parents[1]
ARQ_LEITURAS = BASE / "data" / "leituras.jsonl"
ARQ_HISTORICO = BASE / "data" / "historico.csv"
ARQ_COMANDOS = BASE / "data" / "comandos.jsonl"

# ------------------------------------------------------------
# Configuracao da pagina
# ------------------------------------------------------------
st.set_page_config(page_title="Mini-SCADA EB-13", layout="wide")
st.title("Mini-SCADA - Estacao de Bombeamento EB-13")
st.caption(
    "Supervisor Python/Streamlit. Le pacotes JSON Lines do dispositivo C++, "
    "exibe leituras, alarmes e estado das bombas, e registra comandos."
)


# ------------------------------------------------------------
# Funcoes auxiliares
# ------------------------------------------------------------
def ler_pacotes(caminho: Path) -> list[dict]:
    """Le o arquivo JSONL ignorando linhas em branco e quebradas.

    Optamos por ignorar linhas invalidas em vez de abortar porque o
    dispositivo pode estar gravando enquanto o supervisor le, e uma
    linha incompleta no final do arquivo nao deve derrubar a tela.
    """
    if not caminho.exists():
        return []

    pacotes = []
    with caminho.open("r", encoding="utf-8") as fp:
        for linha in fp:
            linha = linha.strip()
            if not linha:
                continue
            try:
                pacotes.append(json.loads(linha))
            except json.JSONDecodeError:
                # linha truncada ou corrompida, pula
                continue
    return pacotes


def expandir_leituras(pacotes: list[dict]) -> pd.DataFrame:
    """Achata o JSON em formato tabular para o grafico e o historico."""
    linhas = []
    for p in pacotes:
        for leitura in p.get("leituras", []):
            linhas.append({
                "estacao": p.get("estacao"),
                "ciclo": p.get("ciclo"),
                "timestamp_pacote": p.get("timestamp"),
                "tag": leitura.get("tag"),
                "tipo": leitura.get("tipo"),
                "valor": leitura.get("valor"),
                "unidade": leitura.get("unidade"),
                "status": leitura.get("status"),
            })
    return pd.DataFrame(linhas)


def gravar_historico(df: pd.DataFrame) -> None:
    """Salva CSV de historico (sobrescreve)."""
    if df.empty:
        return
    ARQ_HISTORICO.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(ARQ_HISTORICO, index=False, encoding="utf-8")


def registrar_comando(nome: str, obs: str = "") -> dict:
    """Anexa um comando ao arquivo de comandos.

    Nesta versao o C++ nao le os comandos de volta - eles ficam
    registrados apenas para auditoria e demonstracao na defesa.
    """
    ARQ_COMANDOS.parent.mkdir(parents=True, exist_ok=True)
    cmd = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "comando": nome,
        "origem": "supervisor_streamlit",
        "observacao": obs,
        "status": "REGISTRADO",
    }
    with ARQ_COMANDOS.open("a", encoding="utf-8") as fp:
        fp.write(json.dumps(cmd, ensure_ascii=False) + "\n")
    return cmd


def carregar_comandos(caminho: Path) -> list[dict]:
    if not caminho.exists():
        return []
    cmds = []
    for linha in caminho.read_text(encoding="utf-8").splitlines():
        linha = linha.strip()
        if not linha:
            continue
        try:
            cmds.append(json.loads(linha))
        except json.JSONDecodeError:
            continue
    return cmds


# ------------------------------------------------------------
# Carga de dados
# ------------------------------------------------------------
pacotes = ler_pacotes(ARQ_LEITURAS)
df = expandir_leituras(pacotes)
gravar_historico(df)

if not pacotes:
    st.warning(
        "Nenhuma leitura encontrada em data/leituras.jsonl. "
        "Rode o dispositivo C++ primeiro para gerar o arquivo."
    )
    st.stop()

ultimo = pacotes[-1]
assinatura = ultimo.get("assinatura", {})

# ------------------------------------------------------------
# Painel superior - resumo
# ------------------------------------------------------------
c1, c2, c3, c4 = st.columns(4)
c1.metric("Estacao", ultimo.get("estacao", "-"))
c2.metric("Ciclo atual", ultimo.get("ciclo", 0))
c3.metric("Nivel baixo", f"{assinatura.get('nivel_baixo', 0)} %")
c4.metric("Pressao alta", f"{assinatura.get('pressao_alta', 0)} bar")

# ------------------------------------------------------------
# Leituras atuais
# ------------------------------------------------------------
st.subheader("Leituras atuais")
leituras_df = pd.DataFrame(ultimo.get("leituras", []))
st.dataframe(leituras_df, use_container_width=True)

# destaque para sensor travado (falha simulada da dupla)
travados = leituras_df[leituras_df["status"] == "TRAVADO"] if not leituras_df.empty else pd.DataFrame()
if not travados.empty:
    st.error(
        "Falha simulada detectada: sensor "
        + ", ".join(travados["tag"].tolist())
        + " sem atualizacao."
    )

# ------------------------------------------------------------
# Estado das bombas
# ------------------------------------------------------------
st.subheader("Estado das bombas")
bombas_df = pd.DataFrame(ultimo.get("bombas", []))
st.dataframe(bombas_df, use_container_width=True)

# ------------------------------------------------------------
# Historico
# ------------------------------------------------------------
st.subheader("Historico operacional")
if not df.empty:
    pivot = df.pivot_table(
        index="ciclo", columns="tipo", values="valor", aggfunc="last"
    )
    variaveis = [v for v in ["nivel", "pressao", "vazao", "temperatura_motor"] if v in pivot.columns]
    if variaveis:
        st.line_chart(pivot[variaveis])
    st.dataframe(df.tail(40), use_container_width=True)

# ------------------------------------------------------------
# Alarmes ativos
# ------------------------------------------------------------
st.subheader("Alarmes ativos")
alarmes_df = pd.DataFrame(ultimo.get("alarmes", []))
if alarmes_df.empty:
    st.success("Nenhum alarme ativo no ultimo ciclo.")
else:
    st.dataframe(alarmes_df, use_container_width=True)

# ------------------------------------------------------------
# Comandos de atuacao
# ------------------------------------------------------------
st.subheader("Comandos de atuacao")
ca, cb, cc, cd = st.columns(4)
if ca.button("Ligar bomba A"):
    cmd = registrar_comando("LIGAR_BOMBA_A", "partida manual via supervisor")
    st.success(f"Comando registrado: {cmd['comando']}")
if cb.button("Desligar bomba A"):
    cmd = registrar_comando("DESLIGAR_BOMBA_A", "parada manual via supervisor")
    st.success(f"Comando registrado: {cmd['comando']}")
if cc.button("Ligar bomba B"):
    cmd = registrar_comando("LIGAR_BOMBA_B", "partida manual via supervisor")
    st.success(f"Comando registrado: {cmd['comando']}")
if cd.button("Resetar bloqueios"):
    cmd = registrar_comando("RESETAR_BLOQUEIOS", "reconhecimento operacional apos verificacao")
    st.success(f"Comando registrado: {cmd['comando']}")

# historico de comandos
comandos = carregar_comandos(ARQ_COMANDOS)
if comandos:
    st.caption("Ultimos comandos registrados:")
    st.dataframe(pd.DataFrame(comandos).tail(20), use_container_width=True)

# ------------------------------------------------------------
# Rodape - assinatura operacional
# ------------------------------------------------------------
st.info(
    "Falha simulada da dupla EB-13: sensor LT-101 travado entre os ciclos 15 e 24. "
    "Regra extra: bloqueio das bombas quando temperatura do motor entrar em ALERTA."
)
