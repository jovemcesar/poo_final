# Diagrama de classes - EB-13

Diagrama do dispositivo C++. O supervisor Python e cliente do contrato
JSON e nao foi modelado em UML (e procedural por natureza, segue a
estrutura do Streamlit).

```mermaid
classDiagram
    class Sensor {
        #string tag
        #string unidade
        #double valor
        #string status
        +atualizar(int ciclo)*
        +tipo()* string
        +getValor() double
        +getStatus() string
        +setStatus(string)
    }

    class SensorNivel
    class SensorPressao
    class SensorVazao
    class SensorTemperaturaMotor

    Sensor <|-- SensorNivel
    Sensor <|-- SensorPressao
    Sensor <|-- SensorVazao
    Sensor <|-- SensorTemperaturaMotor

    class Bomba {
        -string tag
        -bool ligada
        -bool bloqueada
        -int ciclosLigada
        +ligar()
        +desligar()
        +bloquear()
        +desbloquear()
        +contarCiclo()
    }

    class Alarme {
        +string codigo
        +string severidade
        +string mensagem
        +string timestamp
    }

    class ConfiguracaoDupla {
        +string estacao = "EB-13"
        +int idDupla = 13
        +double nivelBaixo = 23.0
        +double nivelAlto = 81.0
        +double pressaoAlta = 6.3
    }

    class EstacaoBombeamento {
        -ConfiguracaoDupla config
        -vector~Sensor~ sensores
        -vector~Bomba~ bombas
        -vector~Alarme~ alarmes
        -int ciclo
        +atualizarSensores()
        +registrarAlarme()
        +pacoteJson() string
    }

    class RegraControle {
        +aplicar(EstacaoBombeamento)*
        +nome()* string
    }

    class RegraNivel
    class RegraPressao
    class RegraVazaoBaixa
    class RegraSensorTravado
    class RegraBloqueioPorMotor

    RegraControle <|-- RegraNivel
    RegraControle <|-- RegraPressao
    RegraControle <|-- RegraVazaoBaixa
    RegraControle <|-- RegraSensorTravado
    RegraControle <|-- RegraBloqueioPorMotor

    class Comando {
        +executar(EstacaoBombeamento)*
        +nome()* string
    }

    class LigarBombaA
    class DesligarBombaA
    class LigarBombaB
    class ResetarBloqueios

    Comando <|-- LigarBombaA
    Comando <|-- DesligarBombaA
    Comando <|-- LigarBombaB
    Comando <|-- ResetarBloqueios

    class RepositorioJsonLines {
        -string caminho
        +salvar(string linha)
    }

    class FabricaSensores {
        +criar(string tipo)$ Sensor
    }

    EstacaoBombeamento *-- Sensor : contem
    EstacaoBombeamento *-- Bomba : contem
    EstacaoBombeamento *-- Alarme : registra
    EstacaoBombeamento *-- ConfiguracaoDupla : usa
    RegraControle ..> EstacaoBombeamento : modifica
    Comando ..> EstacaoBombeamento : modifica
    FabricaSensores ..> Sensor : cria
```

## Notas sobre o diagrama

- `Sensor`, `RegraControle` e `Comando` sao classes abstratas
  (metodos virtuais puros marcados com `*`).
- A composicao (`*--`) indica que os sensores, bombas e alarmes tem
  o mesmo ciclo de vida da estacao - sao destruidos junto com ela.
- As regras e comandos modificam a estacao (`..>`, dependencia), mas
  nao sao parte dela. Sao injetados no `main()` ou registrados pelo
  supervisor.
- `FabricaSensores` cria sensores mas nao os possui - quem armazena
  e a `EstacaoBombeamento`.

## Onde cada padrao de projeto aparece

| Padrao | Classes envolvidas |
|---|---|
| Strategy | `RegraControle` (interface) + 5 implementacoes |
| Command | `Comando` (interface) + 4 implementacoes |
| Repository | `RepositorioJsonLines` |
| Factory | `FabricaSensores` |
