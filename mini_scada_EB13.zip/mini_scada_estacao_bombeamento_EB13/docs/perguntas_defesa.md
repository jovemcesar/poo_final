# Perguntas de defesa - EB-13

Respostas que cada integrante deve conseguir explicar com as proprias
palavras. As referencias de arquivo e linha facilitam mostrar no
codigo durante a defesa.

## 1. Onde a equipe usou polimorfismo de forma concreta?

Em tres lugares do dispositivo C++:

- **Sensores**: `vector<unique_ptr<Sensor>>` em `EstacaoBombeamento`.
  Quando chamamos `atualizar(ciclo)` em loop, cada sensor responde de
  forma diferente sem que a estacao saiba qual tipo concreto e.
  Mesmo principio em `pacoteJson()` ao chamar `s->tipo()` e
  `s->getValor()`.
- **Regras de controle**: `vector<unique_ptr<RegraControle>>` no `main()`.
  Cada ciclo, o loop chama `r->aplicar(estacao)` sem saber se e regra
  de nivel, de pressao ou a regra extra do motor.
- **Comandos**: a interface `Comando::executar()` permite tratar
  qualquer atuacao da mesma forma. Util para uma futura fila de comandos.

## 2. Quais padroes de projeto foram usados e que problema cada um resolveu?

**Strategy (regras de controle)** - se todas as regras estivessem
dentro de `EstacaoBombeamento`, teriamos um metodo gigante com varios
`if`. Cada regra em classe separada deixa cada uma testavel sozinha
(ver `test_regras.cpp`, um teste por regra).

**Command (atuacoes)** - encapsular cada acao do operador como objeto
permite registrar, enfileirar e auditar comandos. Tambem prepara o
codigo para o dispositivo ler comandos do supervisor em uma proxima
versao - so adicionariamos um executor que chama `comando->executar()`.

**Repository (persistencia)** - `RepositorioJsonLines` esconde o
detalhe de gravar em arquivo. Se trocarmos para TCP ou SQLite, apenas
essa classe muda.

**Factory (criacao de sensores)** - `FabricaSensores::criar(tipo)`
centraliza a criacao por string. Reconhecemos que com 4 tipos fixos
esta "subutilizada", mas mantivemos como ponto de extensao
documentado.

## 3. O que o supervisor sabe sobre o dispositivo? O que ele nao deveria saber?

O supervisor conhece apenas o **contrato JSON** (campos, tipos,
unidades, semantica de status). Nao precisa saber:

- Que linguagem o dispositivo usa
- Como as regras estao implementadas
- Que padroes de projeto foram usados
- Se os valores vem de simulacao ou de hardware real

Esse isolamento e justamente o que permite trocar uma camada sem
quebrar a outra. Se reescrevermos o C++ em Rust amanha, o supervisor
nao muda.

## 4. Qual decisao de arquitetura poderia ser simplificada em uma versao menor?

A Factory de sensores. Com apenas 4 tipos fixos, ela e essencialmente
um `switch`. Em uma versao menor, instanciar direto no construtor da
estacao (como ja fazemos) seria suficiente sem perder nada.

Mantivemos a Factory porque a especificacao pede pelo menos dois
padroes de projeto, e ela documenta o caminho para sensores
configuraveis no futuro.

## 5. Que teste demonstra que uma regra de controle importante nao foi quebrada?

`teste_regra_extra_bloqueio_motor()` em `test_regras.cpp`:

```cpp
EstacaoTeste e;
e.bombas[0].ligar();
e.statusTemperatura = "ALERTA";
aplicarRegraBloqueioPorMotor(e);
assert(e.bombas[0].estaBloqueada());
assert(e.bombas[1].estaBloqueada());
assert(e.temAlarme("ALM_MOTOR_ALERTA"));
```

Esse teste verifica a regra extra da dupla EB-13 (bloqueio por
ALERTA termico). Se alguem alterar a logica e os tres `assert`
ainda passarem, a regra continua funcional. Se quebrar, o teste
acusa imediatamente.

Tambem temos `teste_bloqueio_impede_ligar()` que confirma que a
excecao e lancada ao tentar ligar uma bomba bloqueada.

## 6. Quais parametros pertencem especificamente a esta dupla?

- ID_DUPLA = 13 (soma dos ultimos digitos das matriculas 0275 + 0038
  = 5 + 8 = 13)
- Estacao = EB-13
- Nivel baixo = 23%
- Nivel alto = 81%
- Pressao alta = 6,3 bar
- Falha obrigatoria = sensor LT-101 travado entre os ciclos 15 e 24
- Regra extra = bloqueio por motor em ALERTA termico

Esses valores aparecem em `struct ConfiguracaoDupla` no `main.cpp`,
no teste `teste_parametros_assinatura()`, no `test_json_contract.py`,
no pacote JSON gerado e no README.

## 7. Que parte do codigo precisaria mudar se o limite de pressao da dupla fosse alterado?

Mudaria em **um lugar principal**: `ConfiguracaoDupla::pressaoAlta`
no `main.cpp`. Esse valor e:

- Lido pela `RegraPressao::aplicar()` para decidir se desliga
- Lido pelo `SensorPressao::atualizar()` para setar o status (esse
  valor esta hardcoded como 6.3 no sensor - decisao consciente para
  separar status do sensor da configuracao da estacao)
- Serializado no campo `assinatura.pressao_alta` do pacote JSON
- Exibido pelo supervisor no metric "Pressao alta"

Tambem mudariamos o valor em `test_json_contract.py` (constante
`PRESSAO_ALTA`) e em `test_regras.cpp` (constante `ConfiguracaoDupla::pressaoAlta`).
O ideal seria ter apenas uma constante compartilhada, mas como C++ e
Python nao compartilham codigo facilmente, mantemos o valor em dois
lugares e os testes garantem que os intervalos estao corretos.

## 8. Como a falha simulada aparece no dispositivo, no historico e no supervisor?

- **No dispositivo C++**: em `SensorNivel::atualizar()`, entre os
  ciclos 15 e 24, o sensor faz `status = "TRAVADO"; return;` - nao
  atualiza o valor, apenas marca o status.
- **No pacote JSON**: o campo `leituras[].status` aparece como
  `"TRAVADO"` para o sensor LT-101 nesses ciclos.
- **Na regra de controle**: a `RegraSensorTravado` detecta o status
  e registra o alarme `ALM_SENSOR_TRAVADO` (severidade ALTA).
- **No supervisor Streamlit**: o `app.py` filtra leituras com status
  TRAVADO e exibe um `st.error()` destacando a falha. O alarme
  aparece na tabela "Alarmes ativos". No grafico historico, a linha
  do nivel fica plana durante o periodo da falha (porque o valor
  nao muda enquanto travado).

## Observacao para a defesa

Cada integrante deve conseguir:
1. Abrir o arquivo onde a logica esta
2. Apontar a linha
3. Explicar a decisao em portugues claro, sem decorar a resposta

A pergunta 4 ("o que poderia ser simplificado") e a mais cobrada na
banca - mostre que voce sabe os limites do proprio projeto.
