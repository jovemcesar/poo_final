# Roteiro da apresentacao - EB-13

Tempo alvo: 10 a 12 minutos para a dupla + entrevista individual.

## 1. Problema e escopo (1 min)

Estacao de bombeamento precisa de supervisao em tempo real:
acompanhar nivel do poco, pressao na linha, vazao e temperatura
do motor. Quando algum limite e ultrapassado, e preciso intervir
(ligar, desligar, bloquear). Simulamos esse cenario com dispositivo
em C++ e supervisor em Python.

## 2. Arquitetura geral (1 min)

Mostrar o desenho no README - duas camadas, comunicacao por arquivo
JSON Lines. Por que arquivo e nao TCP: simplicidade, leitura
incremental, pacotes auto-contidos.

## 3. Diagrama de classes (1 min)

Abrir `docs/diagrama_classes.md`. Apontar:
- a hierarquia de Sensor
- a hierarquia de RegraControle (onde mora o Strategy)
- a hierarquia de Comando

## 4. Contrato JSON (1 min)

Abrir um pacote real de `data/leituras.jsonl`. Mostrar os campos
obrigatorios (estacao, ciclo, leituras, bombas, alarmes) e o
campo `assinatura` com os parametros da dupla.

## 5. Assinatura operacional da dupla (30 s)

Mostrar no README a tabela com:
- ID_DUPLA = 13 (5 + 8 das matriculas)
- EB-13
- niveis 23% / 81%
- pressao 6,3 bar
- falha: sensor travado ciclos 15-24
- regra extra: bloqueio por motor

## 6. Demonstracao do dispositivo C++ (2 min)

Compilar e rodar `./dispositivo`. Mostrar os pacotes JSON aparecendo
no console. Deixar rodar uns 30 segundos para gerar dados suficientes.
Apontar:
- mudanca de status quando o nivel sobe/desce
- aparecimento de `"status": "TRAVADO"` por volta do ciclo 15
- alarmes aparecendo na lista quando os limites sao ultrapassados

## 7. Demonstracao do supervisor Streamlit (2 min)

`streamlit run app.py`. Mostrar:
- metricas no topo (estacao, ciclo, nivel baixo, pressao alta)
- tabela de leituras atuais
- destaque vermelho quando o sensor esta TRAVADO
- estado das bombas (ligada/bloqueada)
- grafico historico das quatro variaveis
- tabela de alarmes
- botoes de comando (clicar um para mostrar registro)

## 8. Historico, comandos e alarmes (1 min)

Abrir `data/comandos.jsonl` apos clicar nos botoes - mostrar que
cada comando virou uma linha. Abrir `data/historico.csv` - mostrar
que o supervisor mantem historico tabular.

## 9. Falha simulada e regra especifica (1 min)

Apontar no codigo:
- `SensorNivel::atualizar()` - linhas que fazem `status = "TRAVADO"`
  entre os ciclos 15 e 24
- `RegraBloqueioPorMotor::aplicar()` - a regra extra completa
- No supervisor, mostrar o aviso vermelho quando a falha acontece

## 10. Testes (1 min)

Rodar `./test_regras` - mostrar os 13 testes passando.
Rodar `pytest tests/` - mostrar os 17 testes Python passando.
Abrir um teste especifico (sugestao: `teste_regra_extra_bloqueio_motor`)
e mostrar como ele exercita a regra.

## 11. Uso de IA e rastreabilidade (30 s)

Abrir `AI_LOG.md`. Mostrar uma entrada que foi aceita e uma que foi
rejeitada com justificativa. Mencionar que o AI_LOG e cronologico.

## 12. Principais decisoes e limitacoes (1 min)

Decisoes:
- 4 padroes de projeto (Strategy e Command como principais)
- Comunicacao por arquivo
- Tudo em um unico .cpp para simplificar compilacao no lab

Limitacoes (importante mostrar consciencia):
- Comandos do supervisor nao sao executados de volta no dispositivo
- Simulacao com numeros pseudo-aleatorios, nao calculo hidraulico
- Factory esta subutilizada com 4 tipos fixos

## Cronometro sugerido

| Etapa | Duracao | Acumulado |
|---|---|---|
| 1. Problema | 1:00 | 1:00 |
| 2. Arquitetura | 1:00 | 2:00 |
| 3. Diagrama | 1:00 | 3:00 |
| 4. JSON | 1:00 | 4:00 |
| 5. Assinatura | 0:30 | 4:30 |
| 6. Demo C++ | 2:00 | 6:30 |
| 7. Demo Streamlit | 2:00 | 8:30 |
| 8. Historico | 1:00 | 9:30 |
| 9. Falha + regra | 1:00 | 10:30 |
| 10. Testes | 1:00 | 11:30 |
| 11. AI_LOG | 0:30 | 12:00 |
| 12. Limitacoes | 1:00 | 13:00 |

## Dicas

- Antes da apresentacao, rode o dispositivo por uns 30 segundos para
  ter `data/leituras.jsonl` ja populado. Apresentacao com tela vazia
  e ruim.
- Tenha dois terminais ja abertos: um para o C++, outro para o
  Streamlit.
- Se o professor pedir para alterar algo ao vivo (item da especificacao),
  o lugar mais seguro de mexer e o limite de pressao em
  `ConfiguracaoDupla::pressaoAlta`. So mudar o valor, recompilar e
  mostrar o efeito.
