# AI_LOG - Mini-SCADA EB-13

Registro do uso de IA durante o desenvolvimento. Cada entrada inclui
o que foi pedido, o que foi aceito, o que foi rejeitado e a
justificativa tecnica.

Ferramenta principal usada: ChatGPT (modelo conversacional) e
documentacao oficial das bibliotecas.

---

## Entrada 1

- **Data**: dia 1 de desenvolvimento
- **Ferramenta**: ChatGPT
- **Pedido**: "como gerar timestamp ISO 8601 em C++ portavel entre
  Linux e Windows?"
- **Aceito**: a ideia de usar `chrono::system_clock` + `put_time`
  com `#ifdef _WIN32` para escolher `localtime_s` vs `localtime_r`.
- **Rejeitado**: a primeira sugestao usava `gmtime` (UTC). Trocamos
  por `localtime` porque queriamos o horario local da estacao.
- **Justificativa**: timestamp local fica mais facil de comparar com
  o relogio da sala onde a defesa acontece. UTC seria mais correto
  tecnicamente mas atrapalha na hora de explicar.

---

## Entrada 2

- **Data**: dia 1
- **Ferramenta**: ChatGPT
- **Pedido**: "como modelar regras de controle separadas da classe
  principal sem usar enum + switch?"
- **Aceito**: usar padrao Strategy com classe base `RegraControle` e
  um `aplicar(Estacao&)` virtual puro.
- **Rejeitado**: a sugestao inicial era passar a estacao como `const&`
  e a regra retornar uma lista de comandos a serem aplicados pelo
  chamador. Rejeitamos porque dobrava o numero de tipos e nao trazia
  ganho real para o escopo do trabalho.
- **Justificativa**: o padrao Strategy direto, com a regra modificando
  a estacao via referencia mutavel, e mais simples de defender em
  banca e mais facil de testar.

---

## Entrada 3

- **Data**: dia 2
- **Ferramenta**: ChatGPT
- **Pedido**: "qual a melhor forma de serializar struct em JSON sem
  usar biblioteca externa?"
- **Aceito**: montar a string manualmente com `stringstream`. E feio
  mas elimina dependencia.
- **Rejeitado**: a IA sugeriu `nlohmann/json`. Recusamos para evitar
  ter que configurar dependencia externa no laboratorio.
- **Justificativa**: o JSON do projeto e simples e fixo. Nao compensa
  trazer biblioteca so para isso. Alem disso, escrever a serializacao
  manualmente garante que entendemos o contrato JSON byte a byte.

---

## Entrada 4

- **Data**: dia 2
- **Ferramenta**: ChatGPT
- **Pedido**: "como evitar que linha JSON corrompida derrube o
  supervisor Streamlit?"
- **Aceito**: `try/except json.JSONDecodeError` em cada linha, com
  `continue` para pular linhas invalidas.
- **Rejeitado**: validar com `jsonschema`. Excesso para o escopo.
- **Justificativa**: durante a execucao real, o C++ pode estar
  gravando enquanto o Python le. Uma linha truncada no final do
  arquivo e cenario esperado, nao excepcao. O `continue` resolve
  bem.

---

## Entrada 5

- **Data**: dia 3
- **Ferramenta**: ChatGPT
- **Pedido**: "como testar regra de controle sem instanciar a
  classe inteira EstacaoBombeamento?"
- **Aceito**: criar uma estrutura `EstacaoTeste` no proprio arquivo
  de teste, com os mesmos campos relevantes mas valores injetaveis
  diretamente.
- **Rejeitado**: usar GoogleTest com mocks. Nao temos a biblioteca
  instalada no lab e a configuracao do CMake fica mais complexa.
- **Justificativa**: o teste precisa ser standalone (`g++ test.cpp -o
  test`). A estrutura simplificada de teste atende e fica mais
  clara de defender.

---

## Entrada 6

- **Data**: dia 3
- **Ferramenta**: ChatGPT
- **Pedido**: "como o Streamlit pode atualizar dados em tempo real
  sem o usuario apertar F5?"
- **Aceito**: nenhum codigo, apenas explicacao. Streamlit re-executa
  o script a cada interacao - para auto-refresh real precisaria de
  `st.experimental_rerun` ou polling.
- **Rejeitado**: implementar auto-refresh com timer. Adicionaria
  complexidade sem necessidade - o operador clicar no botao "Rerun"
  do proprio Streamlit ja resolve para a demonstracao.
- **Justificativa**: priorizamos ter as funcionalidades obrigatorias
  funcionando perfeitamente em vez de extras nao pedidos.

---

## Entrada 7

- **Data**: dia 4
- **Ferramenta**: ChatGPT
- **Pedido**: "review do main.cpp - o que poderia estar mal?"
- **Aceito**: sugestao de evitar `using namespace std;` em codigo
  maior. Discutimos e mantivemos para nao reescrever tudo - e um
  projeto educacional, nao biblioteca.
- **Rejeitado**: maioria das sugestoes (separar em multiplos arquivos,
  usar smart pointer em todo lugar). Trade-off de complexidade nao
  compensa para o escopo.
- **Justificativa**: melhor um arquivo unico claro que entendemos
  100% do que tres arquivos elegantes que precisariamos defender
  superficialmente.

---

## Entrada 8

- **Data**: dia 4
- **Ferramenta**: ChatGPT
- **Pedido**: "ajuda a escrever o README de forma profissional"
- **Aceito**: estrutura geral (descricao -> dupla -> assinatura ->
  arquitetura -> POO -> padroes -> como rodar -> limitacoes).
- **Rejeitado**: linguagem polida demais com adjetivos como
  "robusto", "eficiente", "elegante". Reescrevemos em portugues
  mais direto.
- **Justificativa**: README com tom de marketing fica obvio que e
  texto gerado. Preferimos linguagem objetiva, igual ao tom de quem
  realmente entendeu o que fez.

---

## Entrada 9

- **Data**: dia 5
- **Ferramenta**: ChatGPT
- **Pedido**: "vale a pena adicionar State Machine para o estado das
  bombas?"
- **Aceito**: nada do codigo sugerido.
- **Rejeitado**: a implementacao inteira. State Machine com classes
  separadas para `EstadoLigada`, `EstadoDesligada`, `EstadoBloqueada`
  seria sobre-engenharia para 3 estados que ja sao bem cobertos por
  duas flags `bool`.
- **Justificativa**: padroes de projeto devem resolver problemas
  reais. Adicionar State so para ter um quinto padrao no relatorio
  seria exatamente o tipo de "complexidade adicional sem ganho" que
  a especificacao adverte.

---

## Entrada 10

- **Data**: dia 5
- **Ferramenta**: ChatGPT
- **Pedido**: "escrever testes para o contrato JSON"
- **Aceito**: a ideia de testar tres categorias: parametros da
  assinatura, estrutura do contrato e tolerancia a falhas do parser.
- **Rejeitado**: a primeira versao gerada nao testava arquivo real
  em disco - so dicts em memoria. Adicionamos `test_le_arquivo_jsonl_real`
  com `tmp_path` para garantir que a leitura funciona ponta a ponta.
- **Justificativa**: teste que nao toca disco nao garante que o
  parser real do `app.py` funciona. O teste com `tmp_path` cobre
  o caminho completo.

---

## Observacao final

Todo trecho de codigo aceito da IA foi lido, entendido e adaptado
antes de entrar no projeto. Em particular, as decisoes de:

- nao usar bibliotecas JSON externas
- nao usar framework de teste em C++
- manter um arquivo unico para o dispositivo

foram tomadas pela dupla apos discussao, contrariando sugestoes
iniciais da IA.

Os dois integrantes conseguem explicar qualquer parte do codigo
entregue.
