# Mini-SCADA - Estacao de Bombeamento EB-13

Projeto final da disciplina de Programacao Orientada a Objetos.

Aplicacao em duas camadas que simula e supervisiona uma estacao de
bombeamento. O dispositivo em C++ simula sensores, bombas e regras
de controle. O supervisor em Python/Streamlit le os pacotes JSON
gerados pelo dispositivo, exibe leituras, alarmes e registra comandos
de atuacao.

## Dupla

| Matricula | Responsabilidade principal |
|---|---|
| 20232ceca0275 | dispositivo C++ (sensores, regras, testes do dispositivo) |
| 20232ceca0038 | supervisor Python, contrato JSON, testes do supervisor |

Os dois integrantes participaram de revisao cruzada do README, da
arquitetura geral e da apresentacao final.

## Assinatura operacional da dupla

ID_DUPLA = ultimo digito de **20232ceca0275** (5) + ultimo digito
de **20232ceca0038** (8) = **13**.

| Item | Valor adotado |
|---|---|
| Identificador da estacao | EB-13 |
| ID_DUPLA | 13 |
| Nivel baixo | 23% |
| Nivel alto | 81% |
| Pressao alta | 6,3 bar |
| Falha obrigatoria | Sensor LT-101 (nivel) travado entre os ciclos 15 e 24 |
| Regra extra | Bloqueio de partida das bombas quando o motor estiver em ALERTA termico |

Esses valores aparecem em quatro lugares do projeto:
- `dispositivo_cpp/src/main.cpp` (struct `ConfiguracaoDupla`)
- `dispositivo_cpp/tests/test_regras.cpp`
- `supervisor_python/tests/test_json_contract.py`
- pacote JSON gerado em tempo de execucao (campo `assinatura`)

## Arquitetura em duas camadas

```
+---------------------+        leituras.jsonl       +-----------------------+
|  dispositivo_cpp/   |  ---------------------->    |  supervisor_python/   |
|  (simulacao + POO)  |                             |  (Streamlit + pandas) |
+---------------------+                             +-----------------------+
                                                          |
                                                          v
                                                    comandos.jsonl
                                                    historico.csv
```

- `dispositivo_cpp/`: roda 80 ciclos, atualiza sensores, aplica regras
  de controle e grava um pacote JSON por linha em `data/leituras.jsonl`.
- `supervisor_python/`: le os pacotes, monta o painel, escreve historico
  CSV e registra comandos do operador em `data/comandos.jsonl`.
- `data/`: ponto de comunicacao entre as duas camadas.

A comunicacao por arquivo foi escolhida por simplicidade. Discutimos
usar TCP mas o ganho nao compensava o esforco para este escopo - o
supervisor consegue ler o arquivo incrementalmente sem problema.

## Sensores simulados

| Sensor | Tag | Unidade | Funcao |
|---|---|---|---|
| Nivel do poco | LT-101 | % | Mede o nivel no poco de succao (falha simulada da dupla) |
| Pressao | PT-201 | bar | Pressao na linha de recalque |
| Vazao | FT-301 | m3/h | Vazao bombeada |
| Temperatura do motor | TT-401 | C | Condicao termica dos motores |

## Bombas

Duas bombas centrifugas: **P-101A** e **P-101B**. Cada uma mantem
estado ligado/desligado, flag de bloqueio operacional e contador de
ciclos em operacao.

## Regras de controle

1. **Controle por nivel** - liga as duas bombas quando o nivel passa
   de 81% e desliga quando cai abaixo de 23%.
2. **Protecao por pressao** - desliga todas as bombas quando a pressao
   ultrapassa 6,3 bar.
3. **Alarme de vazao baixa** - registra alarme quando ha bomba ligada
   e vazao abaixo de 15 m3/h (possivel obstrucao ou cavitacao).
4. **Deteccao de sensor travado** - detecta a falha obrigatoria da
   dupla (sensor LT-101 sem atualizacao).
5. **Bloqueio por motor (regra extra)** - quando o sensor de temperatura
   do motor entra em ALERTA, as duas bombas sao bloqueadas e so podem
   voltar a operar apos o comando `RESETAR_BLOQUEIOS`.

## Comandos de atuacao

| Comando | Funcao |
|---|---|
| LIGAR_BOMBA_A | Solicita partida de P-101A |
| DESLIGAR_BOMBA_A | Solicita parada de P-101A |
| LIGAR_BOMBA_B | Solicita partida de P-101B |
| RESETAR_BLOQUEIOS | Remove bloqueios operacionais apos verificacao |

Nesta versao os comandos sao registrados em `comandos.jsonl` para
auditoria, mas o dispositivo C++ nao le os comandos de volta em
tempo real (ver limitacoes).

## Alarmes

| Codigo | Severidade | Condicao |
|---|---|---|
| ALM_NIVEL_ALTO | ALTA | Nivel acima de 81% |
| ALM_NIVEL_BAIXO | MEDIA | Nivel abaixo de 23% |
| ALM_PRESSAO_ALTA | CRITICA | Pressao acima de 6,3 bar |
| ALM_VAZAO_BAIXA | MEDIA | Vazao baixa com bomba ligada |
| ALM_SENSOR_TRAVADO | ALTA | Sensor LT-101 sem atualizacao (falha simulada) |
| ALM_MOTOR_ALERTA | CRITICA | Temperatura do motor em ALERTA |

## Contrato JSON Lines

Cada linha de `data/leituras.jsonl` e um pacote completo.

### Campos do pacote

| Campo | Tipo | Obrigatorio | Descricao |
|---|---|---|---|
| estacao | string | sim | Identificador da estacao (ex: "EB-13") |
| ciclo | int | sim | Numero do ciclo de simulacao |
| timestamp | string ISO 8601 | sim | Instante de geracao do pacote |
| assinatura | objeto | sim | Parametros da dupla |
| leituras | lista | sim | Leituras dos sensores no ciclo |
| bombas | lista | sim | Estado de cada bomba |
| alarmes | lista | sim | Alarmes ativos no ciclo (pode ser vazia) |

### Campos de cada leitura

| Campo | Tipo | Obrigatorio | Descricao |
|---|---|---|---|
| tag | string | sim | Identificador do sensor |
| tipo | string | sim | Tipo (nivel, pressao, vazao, temperatura_motor) |
| valor | numero | sim | Valor simulado |
| unidade | string | sim | Unidade de medida |
| timestamp | string ISO 8601 | sim | Instante da leitura |
| status | string | sim | OK, ALTO, BAIXO, ALERTA ou TRAVADO |

### Exemplo de pacote

```json
{"estacao":"EB-13","ciclo":1,"timestamp":"2026-06-26T10:00:00","assinatura":{"id_dupla":13,"nivel_baixo":23.0,"nivel_alto":81.0,"pressao_alta":6.3},"leituras":[{"tag":"LT-101","tipo":"nivel","valor":48.12,"unidade":"%","timestamp":"2026-06-26T10:00:00","status":"OK"}],"bombas":[{"tag":"P-101A","ligada":false,"bloqueada":false,"ciclos":0}],"alarmes":[]}
```

## POO aplicada

| Conceito | Onde aparece |
|---|---|
| Classes e objetos | `Sensor`, `Bomba`, `Alarme`, `EstacaoBombeamento`, `RegraControle`, `Comando` |
| Encapsulamento | atributos `protected`/`private` em `Sensor` e `Bomba`, acessados por getters |
| Heranca | `Sensor` -> `SensorNivel`, `SensorPressao`, `SensorVazao`, `SensorTemperaturaMotor` |
| Polimorfismo | `vector<unique_ptr<Sensor>>` percorrido com `atualizar()` virtual. Mesmo padrao para `RegraControle` e `Comando` |
| Abstracao | `RegraControle` e `Comando` sao interfaces puras (metodos virtuais puros) |
| Composicao | `EstacaoBombeamento` contem vetores de sensores, bombas e alarmes |
| Excecoes | `Bomba::ligar()` lanca `runtime_error` se bloqueada; `valorSensor()` lanca se tipo nao existe; `RepositorioJsonLines` lanca se nao consegue abrir o arquivo |
| Colecoes | `vector<unique_ptr<Sensor>>`, `vector<Bomba>`, `vector<Alarme>`, `vector<unique_ptr<RegraControle>>` |

## Padroes de projeto

Usamos quatro padroes. Os dois principais para a defesa sao **Strategy**
(regras) e **Command** (atuacoes).

### Strategy - regras de controle

As cinco regras herdam de `RegraControle` e implementam `aplicar()`.
A estacao apenas itera pela lista de regras sem conhecer o que cada
uma faz por dentro. Considermos colocar tudo em metodos da `EstacaoBombeamento`
mas isso geraria um metodo gigante com muitos `if`, dificil de testar
isoladamente. Com Strategy cada regra e testavel sozinha (ver
`test_regras.cpp`).

### Command - comandos de atuacao

Cada comando do operador (`LigarBombaA`, `DesligarBombaA`, `LigarBombaB`,
`ResetarBloqueios`) e uma classe que implementa `Comando::executar()`.
Vantagem: facilita registrar, enfileirar e auditar comandos. Tambem
deixa pronto o caminho para o dispositivo ler comandos do supervisor
em uma proxima versao.

### Repository - persistencia

`RepositorioJsonLines` isola a gravacao em arquivo. Se trocarmos para
TCP ou SQLite, so essa classe muda. O resto do codigo nao sabe onde
o pacote vai parar.

### Factory - criacao de sensores

`FabricaSensores::criar(tipo)` centraliza a instanciacao por string.
Util se no futuro os sensores forem carregados de arquivo de configuracao.
Reconhecemos que com apenas 4 tipos fixos a Factory esta "subutilizada",
mas mantivemos como ponto de extensao documentado.

## Como compilar o dispositivo C++

A partir da raiz do projeto:

```bash
cd dispositivo_cpp
mkdir -p build && cd build
cmake ..
cmake --build .
./dispositivo
```

No Windows o executavel pode aparecer como `dispositivo.exe`.

Tambem e possivel compilar direto sem CMake:

```bash
cd dispositivo_cpp/src
g++ -std=c++17 main.cpp -o dispositivo
mkdir -p ../../data
./dispositivo
```

## Como executar o supervisor

Em outro terminal, na raiz do projeto:

```bash
cd supervisor_python
pip install -r requirements.txt
streamlit run app.py
```

A pagina abre em `http://localhost:8501`. Se o arquivo
`data/leituras.jsonl` ainda nao existir, o supervisor mostra aviso
para rodar o dispositivo primeiro.

## Como rodar os testes

### C++

```bash
cd dispositivo_cpp/tests
g++ -std=c++17 test_regras.cpp -o test_regras
./test_regras
```

Saida esperada: 13 testes passando, cobrindo todas as regras de
controle e os parametros da assinatura EB-13.

### Python

```bash
cd supervisor_python
pip install -r requirements.txt
pytest tests/ -v
```

Saida esperada: 17 testes passando, cobrindo contrato JSON, parametros
da assinatura e tolerancia a falhas do parser.

## Estrutura de pastas

```
mini_scada_estacao_bombeamento/
├── README.md
├── AI_LOG.md
├── data/
│   └── .gitkeep
├── dispositivo_cpp/
│   ├── CMakeLists.txt
│   ├── src/
│   │   └── main.cpp
│   └── tests/
│       └── test_regras.cpp
├── supervisor_python/
│   ├── app.py
│   ├── requirements.txt
│   └── tests/
│       └── test_json_contract.py
└── docs/
    ├── diagrama_classes.md
    ├── perguntas_defesa.md
    └── roteiro_apresentacao.md
```

## Limitacoes conhecidas

- O dispositivo C++ desta versao **nao le** os comandos gravados pelo
  supervisor. Os comandos ficam registrados em `comandos.jsonl` apenas
  para auditoria. Para fechar o ciclo seria preciso adicionar uma
  thread de leitura no C++ ou um socket - ficou fora do escopo.
- A simulacao usa numeros pseudo-aleatorios com perfis temporais
  fixos (chuva no ciclo 8, obstrucao 28-36, aquecimento 32-44). Nao
  representa calculo hidraulico real.
- O historico CSV e reescrito a cada carregamento do supervisor a
  partir do JSONL atual. Se quiser preservar dados antigos, copie o
  CSV antes de reiniciar o dispositivo.
- A comunicacao por arquivo nao tem mecanismo de "ack". Se o supervisor
  cair, ele apenas relera o JSONL inteiro na proxima vez.
- O contador de ciclos da bomba e simplificado (incrementa 1 por ciclo
  enquanto ligada). Nao representa horimetro real.

## Divisao de trabalho

| Integrante | O que fez | O que revisou |
|---|---|---|
| 20232ceca0275 | dispositivo C++, regras, testes C++ | app.py, contrato JSON, README |
| 20232ceca0038 | supervisor Streamlit, testes Python, contrato JSON | main.cpp, regras, diagrama de classes |

Ambos participaram do README, do AI_LOG e da preparacao da apresentacao.
