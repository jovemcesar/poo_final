// Testes das regras de controle - Mini-SCADA EB-13
// Compila standalone: g++ test_regras.cpp -o test_regras && ./test_regras
//
// Cada teste instancia a estacao, forca um estado e verifica o comportamento.
// Nao usamos framework externo porque a maquina do lab nao tem gtest instalado.

#include <cassert>
#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <stdexcept>
#include <algorithm>
#include <sstream>
#include <chrono>
#include <iomanip>

using namespace std;

// -- copia minima das classes necessarias para os testes --
// (nao incluimos main.cpp diretamente para evitar conflito de main)

static string agora() {
    auto tp = chrono::system_clock::now();
    time_t t = chrono::system_clock::to_time_t(tp);
    tm tmv{};
#ifdef _WIN32
    localtime_s(&tmv, &t);
#else
    localtime_r(&t, &tmv);
#endif
    stringstream ss;
    ss << put_time(&tmv, "%Y-%m-%dT%H:%M:%S");
    return ss.str();
}

struct ConfiguracaoDupla {
    string estacao     = "EB-13";
    int    idDupla     = 13;
    double nivelBaixo  = 23.0;
    double nivelAlto   = 81.0;
    double pressaoAlta = 6.3;
};

struct Alarme {
    string codigo, severidade, mensagem, timestamp;
    Alarme(string c, string s, string m)
        : codigo(c), severidade(s), mensagem(m), timestamp(agora()) {}
};

class Bomba {
    string tag;
    bool   ligada, bloqueada;
    int    ciclos;
public:
    explicit Bomba(string t) : tag(t), ligada(false), bloqueada(false), ciclos(0) {}
    string getTag()          const { return tag; }
    bool   estaLigada()      const { return ligada; }
    bool   estaBloqueada()   const { return bloqueada; }
    void ligar()    { if (bloqueada) throw runtime_error("bloqueada: " + tag); ligada = true; }
    void desligar() { ligada    = false; }
    void bloquear() { bloqueada = true; ligada = false; }
    void desbloquear() { bloqueada = false; }
};

// Estacao de teste: permite injetar valores de sensores diretamente
// sem depender da simulacao aleatoria
class EstacaoTeste {
public:
    ConfiguracaoDupla config;
    vector<Bomba>     bombas;
    vector<Alarme>    alarmes;

    // valores injetaveis por teste
    double valorNivel      = 50.0;
    double valorPressao    = 3.0;
    double valorVazao      = 30.0;
    double valorTemperatura= 55.0;
    string statusNivel     = "OK";
    string statusTemperatura = "OK";

    EstacaoTeste() {
        bombas.emplace_back("P-101A");
        bombas.emplace_back("P-101B");
    }

    void registrarAlarme(const string& cod, const string& sev, const string& msg) {
        bool jaTem = any_of(alarmes.begin(), alarmes.end(),
            [&](const Alarme& a){ return a.codigo == cod; });
        if (!jaTem) alarmes.emplace_back(cod, sev, msg);
    }

    bool temAlarme(const string& cod) const {
        return any_of(alarmes.begin(), alarmes.end(),
            [&](const Alarme& a){ return a.codigo == cod; });
    }

    void limpar() {
        alarmes.clear();
        for (auto& b : bombas) { b.desligar(); b.desbloquear(); }
    }
};

// -- logica das regras copiada do main.cpp --

void aplicarRegraNivel(EstacaoTeste& e) {
    double nivel = e.valorNivel;
    if (nivel >= e.config.nivelAlto) {
        for (auto& b : e.bombas)
            if (!b.estaBloqueada()) b.ligar();
        e.registrarAlarme("ALM_NIVEL_ALTO", "ALTA", "nivel alto");
    } else if (nivel <= e.config.nivelBaixo) {
        for (auto& b : e.bombas) b.desligar();
        e.registrarAlarme("ALM_NIVEL_BAIXO", "MEDIA", "nivel baixo");
    }
}

void aplicarRegraPressao(EstacaoTeste& e) {
    if (e.valorPressao > e.config.pressaoAlta) {
        for (auto& b : e.bombas) b.desligar();
        e.registrarAlarme("ALM_PRESSAO_ALTA", "CRITICA", "pressao alta");
    }
}

void aplicarRegraVazaoBaixa(EstacaoTeste& e) {
    bool ligada = false;
    for (const auto& b : e.bombas) ligada = ligada || b.estaLigada();
    if (ligada && e.valorVazao < 15.0)
        e.registrarAlarme("ALM_VAZAO_BAIXA", "MEDIA", "vazao baixa");
}

void aplicarRegraSensorTravado(EstacaoTeste& e) {
    if (e.statusNivel == "TRAVADO")
        e.registrarAlarme("ALM_SENSOR_TRAVADO", "ALTA", "sensor travado");
}

void aplicarRegraBloqueioPorMotor(EstacaoTeste& e) {
    if (e.statusTemperatura == "ALERTA") {
        for (auto& b : e.bombas) b.bloquear();
        e.registrarAlarme("ALM_MOTOR_ALERTA", "CRITICA", "motor em alerta");
    }
}

// -- testes --

void teste_parametros_assinatura() {
    ConfiguracaoDupla cfg;
    assert(cfg.idDupla     == 13);
    assert(cfg.nivelBaixo  >= 20.0 && cfg.nivelBaixo  <= 35.0);
    assert(cfg.nivelAlto   >= 75.0 && cfg.nivelAlto   <= 90.0);
    assert(cfg.pressaoAlta >= 5.0  && cfg.pressaoAlta <= 8.0);
    assert(cfg.estacao == "EB-13");
    cout << "  [ok] parametros da assinatura operacional (EB-13, ID=13)\n";
}

void teste_nivel_alto_liga_bombas() {
    EstacaoTeste e;
    e.valorNivel = 85.0; // acima de 81%
    aplicarRegraNivel(e);
    assert(e.bombas[0].estaLigada());
    assert(e.bombas[1].estaLigada());
    assert(e.temAlarme("ALM_NIVEL_ALTO"));
    cout << "  [ok] nivel alto (85%) liga as duas bombas e gera alarme\n";
}

void teste_nivel_baixo_desliga_bombas() {
    EstacaoTeste e;
    // liga as bombas primeiro
    e.bombas[0].ligar();
    e.bombas[1].ligar();
    e.valorNivel = 20.0; // abaixo de 23%
    aplicarRegraNivel(e);
    assert(!e.bombas[0].estaLigada());
    assert(!e.bombas[1].estaLigada());
    assert(e.temAlarme("ALM_NIVEL_BAIXO"));
    cout << "  [ok] nivel baixo (20%) desliga bombas e gera alarme\n";
}

void teste_nivel_normal_sem_acao() {
    EstacaoTeste e;
    e.valorNivel = 50.0; // dentro da faixa operacional
    aplicarRegraNivel(e);
    assert(!e.bombas[0].estaLigada());
    assert(e.alarmes.empty());
    cout << "  [ok] nivel normal (50%) sem alarme e sem acionamento\n";
}

void teste_pressao_alta_desliga_bombas() {
    EstacaoTeste e;
    e.bombas[0].ligar();
    e.valorPressao = 7.0; // acima de 6.3 bar
    aplicarRegraPressao(e);
    assert(!e.bombas[0].estaLigada());
    assert(e.temAlarme("ALM_PRESSAO_ALTA"));
    cout << "  [ok] pressao alta (7.0 bar) desliga bomba e gera alarme CRITICA\n";
}

void teste_pressao_no_limite_sem_alarme() {
    EstacaoTeste e;
    e.valorPressao = 6.3; // exatamente no limite - nao deve disparar
    aplicarRegraPressao(e);
    assert(!e.temAlarme("ALM_PRESSAO_ALTA"));
    cout << "  [ok] pressao no limite (6.3 bar) sem alarme\n";
}

void teste_vazao_baixa_com_bomba_ligada() {
    EstacaoTeste e;
    e.bombas[0].ligar();
    e.valorVazao = 10.0; // abaixo de 15
    aplicarRegraVazaoBaixa(e);
    assert(e.temAlarme("ALM_VAZAO_BAIXA"));
    cout << "  [ok] vazao baixa com bomba ligada gera alarme MEDIA\n";
}

void teste_vazao_baixa_sem_bomba_sem_alarme() {
    EstacaoTeste e;
    // nenhuma bomba ligada - alarme nao deve disparar mesmo com vazao baixa
    e.valorVazao = 5.0;
    aplicarRegraVazaoBaixa(e);
    assert(!e.temAlarme("ALM_VAZAO_BAIXA"));
    cout << "  [ok] vazao baixa sem bomba ligada nao gera alarme\n";
}

void teste_falha_sensor_travado() {
    // falha obrigatoria da dupla EB-13: sensor LT-101 travado
    EstacaoTeste e;
    e.statusNivel = "TRAVADO";
    aplicarRegraSensorTravado(e);
    assert(e.temAlarme("ALM_SENSOR_TRAVADO"));
    cout << "  [ok] falha obrigatoria: sensor travado gera alarme ALTA\n";
}

void teste_regra_extra_bloqueio_motor() {
    // regra extra da dupla: motor em ALERTA bloqueia partida
    EstacaoTeste e;
    e.bombas[0].ligar(); // bomba ja estava ligada
    e.statusTemperatura = "ALERTA";
    aplicarRegraBloqueioPorMotor(e);
    assert(e.bombas[0].estaBloqueada());
    assert(e.bombas[1].estaBloqueada());
    assert(e.temAlarme("ALM_MOTOR_ALERTA"));
    cout << "  [ok] regra extra: motor em ALERTA bloqueia ambas as bombas\n";
}

void teste_bloqueio_impede_ligar() {
    // bomba bloqueada nao pode ser ligada - deve lancar excecao
    EstacaoTeste e;
    e.bombas[0].bloquear();
    bool excecaoCapturada = false;
    try {
        e.bombas[0].ligar();
    } catch (const runtime_error&) {
        excecaoCapturada = true;
    }
    assert(excecaoCapturada);
    cout << "  [ok] bomba bloqueada lanca excecao ao tentar ligar\n";
}

void teste_alarme_sem_duplicata() {
    // mesmo alarme nao pode aparecer duas vezes no mesmo ciclo
    EstacaoTeste e;
    e.valorNivel = 85.0;
    aplicarRegraNivel(e);
    aplicarRegraNivel(e); // segunda chamada no mesmo ciclo
    int qtd = count_if(e.alarmes.begin(), e.alarmes.end(),
        [](const Alarme& a){ return a.codigo == "ALM_NIVEL_ALTO"; });
    assert(qtd == 1);
    cout << "  [ok] alarme duplicado no mesmo ciclo nao e registrado duas vezes\n";
}

void teste_reset_desbloqueia_bombas() {
    EstacaoTeste e;
    e.bombas[0].bloquear();
    e.bombas[1].bloquear();
    // simula comando RESETAR_BLOQUEIOS
    for (auto& b : e.bombas) b.desbloquear();
    assert(!e.bombas[0].estaBloqueada());
    assert(!e.bombas[1].estaBloqueada());
    // agora deve conseguir ligar
    e.bombas[0].ligar();
    assert(e.bombas[0].estaLigada());
    cout << "  [ok] reset desbloqueia bombas e permite nova partida\n";
}

int main() {
    cout << "Testes EB-13 - Mini-SCADA Estacao de Bombeamento\n";
    cout << "------------------------------------------------\n";

    try {
        teste_parametros_assinatura();
        teste_nivel_alto_liga_bombas();
        teste_nivel_baixo_desliga_bombas();
        teste_nivel_normal_sem_acao();
        teste_pressao_alta_desliga_bombas();
        teste_pressao_no_limite_sem_alarme();
        teste_vazao_baixa_com_bomba_ligada();
        teste_vazao_baixa_sem_bomba_sem_alarme();
        teste_falha_sensor_travado();
        teste_regra_extra_bloqueio_motor();
        teste_bloqueio_impede_ligar();
        teste_alarme_sem_duplicata();
        teste_reset_desbloqueia_bombas();

        cout << "------------------------------------------------\n";
        cout << "Todos os testes passaram.\n";
        return 0;

    } catch (const exception& ex) {
        cerr << "FALHA: " << ex.what() << "\n";
        return 1;
    }
}
