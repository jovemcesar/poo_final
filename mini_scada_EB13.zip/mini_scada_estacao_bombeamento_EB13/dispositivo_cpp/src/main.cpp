// Dispositivo C++ - Mini-SCADA Estacao de Bombeamento EB-13
// Disciplina: Programacao Orientada a Objetos
// Dupla: matriculas 20232ceca0275 e 20232ceca0038 (ID_DUPLA = 13)
//
// Decisoes de projeto:
// - Tudo em arquivo unico por simplicidade de compilacao na maquina da dupla
// - Usamos JSON Lines (uma linha por ciclo) porque facilita leitura incremental
//   no Python sem carregar o arquivo inteiro na memoria
// - Padroes escolhidos: Strategy (regras), Command (atuacoes), Repository (gravacao)
//   e Factory (criacao de sensores). Factory ficou simples porque so temos 4 tipos,
//   mas valeu manter o ponto unico de criacao para o caso de adicionar sensores depois

#include <iostream>
#include <fstream>
#include <vector>
#include <memory>
#include <string>
#include <chrono>
#include <thread>
#include <random>
#include <stdexcept>
#include <iomanip>
#include <sstream>
#include <algorithm>

using namespace std;

// retorna timestamp no formato ISO 8601 - usado em leituras e alarmes
static string agora() {
    auto tp = chrono::system_clock::now();
    time_t t  = chrono::system_clock::to_time_t(tp);
    tm tmv{};
#ifdef _WIN32
    localtime_s(&tmv, &t);
#else
    localtime_r(&t, &tmv);
#endif
    stringstream ss;
    ss << put_time(&tmv, "%Y-%m-%dT%H:%M:%S");
    return ss.str();
}

// -------------------------------------------------------
// Assinatura operacional da dupla
// ID_DUPLA = ultimo digito de 20232ceca0275 (5)
//          + ultimo digito de 20232ceca0038 (8) = 13
// -------------------------------------------------------
struct ConfiguracaoDupla {
    string estacao       = "EB-13";
    int    idDupla       = 13;
    double nivelBaixo    = 23.0;   // dentro do intervalo 20-35%
    double nivelAlto     = 81.0;   // dentro do intervalo 75-90%
    double pressaoAlta   = 6.3;    // dentro do intervalo 5.0-8.0 bar
    // falha obrigatoria: sensor de nivel trava entre ciclos 15 e 24 (10 ciclos)
    // regra extra: bloquear partida das bombas quando motor estiver em ALERTA termico
};

// -------------------------------------------------------
// Hierarquia de sensores (heranca + polimorfismo)
// Sensor e a classe base abstrata. Cada subclasse implementa
// atualizar() e tipo() de forma independente.
// -------------------------------------------------------
class Sensor {
protected:
    string tag;
    string unidade;
    double valor;
    string status;

public:
    Sensor(string t, string u, double v0)
        : tag(t), unidade(u), valor(v0), status("OK") {}

    virtual ~Sensor() = default;

    // metodos puramente virtuais - forcam implementacao nas subclasses
    virtual void   atualizar(int ciclo) = 0;
    virtual string tipo() const = 0;

    string getTag()     const { return tag; }
    string getUnidade() const { return unidade; }
    double getValor()   const { return valor; }
    string getStatus()  const { return status; }
    void   setStatus(const string& s) { status = s; }
};

// Sensor de nivel do poco de succao (tag LT-101)
// Falha simulada: trava entre ciclos 15-24 (10 ciclos conforme assinatura)
class SensorNivel : public Sensor {
    mt19937 gen;
    uniform_real_distribution<double> ruido;

public:
    SensorNivel()
        : Sensor("LT-101", "%", 48.0),
          gen(random_device{}()),
          ruido(-2.0, 2.8) {}

    void atualizar(int ciclo) override {
        // falha obrigatoria da dupla: sensor trava por 10 ciclos
        if (ciclo >= 15 && ciclo < 25) {
            status = "TRAVADO";
            return; // valor nao muda enquanto travado
        }
        valor += ruido(gen);
        // a cada 8 ciclos o nivel sobe um pouco mais rapido (chuva simulada)
        if (ciclo % 8 == 0) valor += 6.5;
        valor  = max(4.0, min(97.0, valor));
        status = "OK";
    }

    string tipo() const override { return "nivel"; }
};

// Sensor de pressao na linha de recalque (tag PT-201)
class SensorPressao : public Sensor {
    mt19937 gen;
    uniform_real_distribution<double> ruido;

public:
    SensorPressao()
        : Sensor("PT-201", "bar", 3.4),
          gen(random_device{}()),
          ruido(-0.15, 0.22) {}

    void atualizar(int ciclo) override {
        valor += ruido(gen);
        // pressao sobe gradualmente entre ciclos 38-48 (simula obstrucao)
        if (ciclo > 38 && ciclo < 48) valor += 0.25;
        valor  = max(0.3, min(8.8, valor));
        // usa o limite da assinatura (6.3 bar) - hardcoded aqui propositalmente
        // para que o status do sensor seja independente da configuracao da estacao
        status = (valor > 6.3) ? "ALTO" : "OK";
    }

    string tipo() const override { return "pressao"; }
};

// Sensor de vazao bombeada (tag FT-301)
class SensorVazao : public Sensor {
    mt19937 gen;
    uniform_real_distribution<double> ruido;

public:
    SensorVazao()
        : Sensor("FT-301", "m3/h", 38.0),
          gen(random_device{}()),
          ruido(-2.5, 2.2) {}

    void atualizar(int ciclo) override {
        valor += ruido(gen);
        // queda de vazao entre ciclos 28-36 (simula possivel cavitacao)
        if (ciclo > 28 && ciclo < 36) valor -= 4.5;
        valor  = max(0.0, min(70.0, valor));
        status = (valor < 15.0) ? "BAIXO" : "OK";
    }

    string tipo() const override { return "vazao"; }
};

// Sensor de temperatura do motor (tag TT-401)
// Quando em ALERTA, a regra extra da dupla bloqueia as bombas
class SensorTemperaturaMotor : public Sensor {
    mt19937 gen;
    uniform_real_distribution<double> ruido;

public:
    SensorTemperaturaMotor()
        : Sensor("TT-401", "C", 51.0),
          gen(random_device{}()),
          ruido(-0.5, 0.9) {}

    void atualizar(int ciclo) override {
        valor += ruido(gen);
        // aquecimento progressivo entre ciclos 32-44
        if (ciclo > 32 && ciclo < 44) valor += 1.4;
        valor  = max(22.0, min(95.0, valor));
        status = (valor > 80.0) ? "ALERTA" : "OK";
    }

    string tipo() const override { return "temperatura_motor"; }
};

// -------------------------------------------------------
// Bomba - modela estado operacional com bloqueio de seguranca
// -------------------------------------------------------
class Bomba {
private:
    string tag;
    bool   ligada;
    bool   bloqueada;
    int    ciclosLigada; // contador simples de tempo em operacao

public:
    explicit Bomba(string t)
        : tag(t), ligada(false), bloqueada(false), ciclosLigada(0) {}

    string getTag()          const { return tag; }
    bool   estaLigada()      const { return ligada; }
    bool   estaBloqueada()   const { return bloqueada; }
    int    getCiclosLigada() const { return ciclosLigada; }

    void ligar() {
        if (bloqueada)
            throw runtime_error("tentativa de ligar bomba bloqueada: " + tag);
        ligada = true;
    }

    void desligar()   { ligada    = false; }
    void bloquear()   { bloqueada = true; ligada = false; }
    void desbloquear(){ bloqueada = false; }

    void contarCiclo() { if (ligada) ciclosLigada++; }
};

// -------------------------------------------------------
// Alarme - registro simples com codigo, severidade e timestamp
// -------------------------------------------------------
struct Alarme {
    string codigo;
    string severidade;
    string mensagem;
    string timestamp;

    Alarme(string c, string s, string m)
        : codigo(c), severidade(s), mensagem(m), timestamp(agora()) {}
};

// -------------------------------------------------------
// Forward declaration necessaria para as interfaces usarem
// EstacaoBombeamento sem definicao circular
// -------------------------------------------------------
class EstacaoBombeamento;

// -------------------------------------------------------
// Interface RegraControle - padrao Strategy
// Cada regra e um objeto separado que recebe a estacao
// e decide o que fazer. Isso evita um metodo gigante com
// varios ifs dentro da propria EstacaoBombeamento.
// -------------------------------------------------------
class RegraControle {
public:
    virtual ~RegraControle() = default;
    virtual void   aplicar(EstacaoBombeamento& e) = 0;
    virtual string nome() const = 0;
};

// -------------------------------------------------------
// Interface Comando - padrao Command
// Cada acao operacional e encapsulada como objeto.
// Facilita registrar, enfileirar e testar comandos isolados.
// -------------------------------------------------------
class Comando {
public:
    virtual ~Comando() = default;
    virtual string executar(EstacaoBombeamento& e) = 0;
    virtual string nome() const = 0;
};

// -------------------------------------------------------
// EstacaoBombeamento - coordena sensores, bombas e alarmes
// Composicao: contem vetores de Sensor, Bomba e Alarme
// -------------------------------------------------------
class EstacaoBombeamento {
private:
    ConfiguracaoDupla          config;
    vector<unique_ptr<Sensor>> sensores;
    vector<Bomba>              bombas;
    vector<Alarme>             alarmes;
    int                        ciclo;

public:
    EstacaoBombeamento() : ciclo(0) {
        // ordem importa: nivel primeiro porque as regras iteram por tipo
        sensores.push_back(make_unique<SensorNivel>());
        sensores.push_back(make_unique<SensorPressao>());
        sensores.push_back(make_unique<SensorVazao>());
        sensores.push_back(make_unique<SensorTemperaturaMotor>());
        bombas.emplace_back("P-101A");
        bombas.emplace_back("P-101B");
    }

    ConfiguracaoDupla          getConfig() const { return config; }
    int                        getCiclo()  const { return ciclo; }
    vector<unique_ptr<Sensor>>& getSensores()    { return sensores; }
    vector<Bomba>&              getBombas()      { return bombas; }
    vector<Alarme>&             getAlarmes()     { return alarmes; }

    double valorSensor(const string& t) const {
        for (const auto& s : sensores)
            if (s->tipo() == t) return s->getValor();
        throw runtime_error("sensor nao encontrado: " + t);
    }

    string statusSensor(const string& t) const {
        for (const auto& s : sensores)
            if (s->tipo() == t) return s->getStatus();
        return "INEXISTENTE";
    }

    void registrarAlarme(const string& cod, const string& sev, const string& msg) {
        // evita duplicar o mesmo alarme no mesmo ciclo
        bool jaTem = any_of(alarmes.begin(), alarmes.end(),
            [&](const Alarme& a){ return a.codigo == cod; });
        if (!jaTem) alarmes.emplace_back(cod, sev, msg);
    }

    void atualizarSensores() {
        ciclo++;
        alarmes.clear();
        for (auto& s : sensores) s->atualizar(ciclo);
        for (auto& b : bombas)   b.contarCiclo();
    }

    // serializa estado das bombas para JSON
    string bombasJson() const {
        stringstream ss;
        ss << "[";
        for (size_t i = 0; i < bombas.size(); ++i) {
            if (i) ss << ",";
            ss << "{\"tag\":\""     << bombas[i].getTag()        << "\""
               << ",\"ligada\":"    << (bombas[i].estaLigada()   ? "true" : "false")
               << ",\"bloqueada\":" << (bombas[i].estaBloqueada()? "true" : "false")
               << ",\"ciclos\":"    << bombas[i].getCiclosLigada()
               << "}";
        }
        ss << "]";
        return ss.str();
    }

    // serializa alarmes ativos para JSON
    string alarmesJson() const {
        stringstream ss;
        ss << "[";
        for (size_t i = 0; i < alarmes.size(); ++i) {
            if (i) ss << ",";
            ss << "{\"codigo\":\""     << alarmes[i].codigo     << "\""
               << ",\"severidade\":\"" << alarmes[i].severidade << "\""
               << ",\"mensagem\":\""   << alarmes[i].mensagem   << "\""
               << ",\"timestamp\":\""  << alarmes[i].timestamp  << "\""
               << "}";
        }
        ss << "]";
        return ss.str();
    }

    // monta o pacote JSON completo do ciclo
    string pacoteJson() const {
        stringstream ss;
        ss << fixed << setprecision(2);
        ss << "{"
           << "\"estacao\":\""  << config.estacao << "\","
           << "\"ciclo\":"      << ciclo           << ","
           << "\"timestamp\":\"" << agora()        << "\","
           << "\"assinatura\":{"
               << "\"id_dupla\":"    << config.idDupla    << ","
               << "\"nivel_baixo\":" << config.nivelBaixo << ","
               << "\"nivel_alto\":"  << config.nivelAlto  << ","
               << "\"pressao_alta\":" << config.pressaoAlta
           << "},";

        ss << "\"leituras\":[";
        for (size_t i = 0; i < sensores.size(); ++i) {
            if (i) ss << ",";
            const auto& s = sensores[i];
            ss << "{"
               << "\"tag\":\""     << s->getTag()    << "\","
               << "\"tipo\":\""    << s->tipo()       << "\","
               << "\"valor\":"     << s->getValor()   << ","
               << "\"unidade\":\"" << s->getUnidade() << "\","
               << "\"timestamp\":\"" << agora()       << "\","
               << "\"status\":\""  << s->getStatus()  << "\""
               << "}";
        }
        ss << "],"
           << "\"bombas\":"  << bombasJson()  << ","
           << "\"alarmes\":" << alarmesJson()
           << "}";
        return ss.str();
    }
};

// -------------------------------------------------------
// Regras de controle - padrao Strategy
// -------------------------------------------------------

// Regra 1: controle por nivel - liga/desliga bombas conforme nivel do poco
class RegraNivel : public RegraControle {
public:
    void aplicar(EstacaoBombeamento& e) override {
        double nivel = e.valorSensor("nivel");
        auto   cfg   = e.getConfig();
        auto&  bbs   = e.getBombas();

        if (nivel >= cfg.nivelAlto) {
            // nivel alto: liga as duas para esvaziar mais rapido
            for (auto& b : bbs)
                if (!b.estaBloqueada()) b.ligar();
            e.registrarAlarme("ALM_NIVEL_ALTO", "ALTA",
                "nivel acima de " + to_string((int)cfg.nivelAlto) + "%");

        } else if (nivel <= cfg.nivelBaixo) {
            // nivel baixo: desliga tudo para nao danificar as bombas a seco
            for (auto& b : bbs) b.desligar();
            e.registrarAlarme("ALM_NIVEL_BAIXO", "MEDIA",
                "nivel abaixo de " + to_string((int)cfg.nivelBaixo) + "%, bombas desligadas");
        }
    }
    string nome() const override { return "controle por nivel"; }
};

// Regra 2: protecao por pressao alta
class RegraPressao : public RegraControle {
public:
    void aplicar(EstacaoBombeamento& e) override {
        if (e.valorSensor("pressao") > e.getConfig().pressaoAlta) {
            for (auto& b : e.getBombas()) b.desligar();
            e.registrarAlarme("ALM_PRESSAO_ALTA", "CRITICA",
                "pressao acima de " + to_string(e.getConfig().pressaoAlta) + " bar, bombas desligadas");
        }
    }
    string nome() const override { return "protecao por pressao"; }
};

// Regra 3: alarme de vazao baixa com bomba ligada
class RegraVazaoBaixa : public RegraControle {
public:
    void aplicar(EstacaoBombeamento& e) override {
        bool ligada = false;
        for (const auto& b : e.getBombas()) ligada = ligada || b.estaLigada();
        if (ligada && e.valorSensor("vazao") < 15.0) {
            e.registrarAlarme("ALM_VAZAO_BAIXA", "MEDIA",
                "vazao baixa com bomba ligada, verificar obstrucao");
        }
    }
    string nome() const override { return "alarme vazao baixa"; }
};

// Regra 4: detecta falha obrigatoria da dupla (sensor de nivel travado)
class RegraSensorTravado : public RegraControle {
public:
    void aplicar(EstacaoBombeamento& e) override {
        if (e.statusSensor("nivel") == "TRAVADO") {
            e.registrarAlarme("ALM_SENSOR_TRAVADO", "ALTA",
                "sensor LT-101 sem atualizacao (falha simulada EB-13)");
        }
    }
    string nome() const override { return "deteccao sensor travado"; }
};

// Regra 5: regra extra da dupla - bloqueia bombas quando motor em alerta termico
class RegraBloqueioPorMotor : public RegraControle {
public:
    void aplicar(EstacaoBombeamento& e) override {
        if (e.statusSensor("temperatura_motor") == "ALERTA") {
            for (auto& b : e.getBombas()) b.bloquear();
            e.registrarAlarme("ALM_MOTOR_ALERTA", "CRITICA",
                "motor em ALERTA termico, partida bloqueada (regra extra EB-13)");
        }
    }
    string nome() const override { return "bloqueio por alerta termico"; }
};

// -------------------------------------------------------
// Comandos de atuacao - padrao Command
// -------------------------------------------------------
class LigarBombaA : public Comando {
public:
    string executar(EstacaoBombeamento& e) override {
        e.getBombas()[0].ligar();
        return "P-101A ligada";
    }
    string nome() const override { return "LIGAR_BOMBA_A"; }
};

class DesligarBombaA : public Comando {
public:
    string executar(EstacaoBombeamento& e) override {
        e.getBombas()[0].desligar();
        return "P-101A desligada";
    }
    string nome() const override { return "DESLIGAR_BOMBA_A"; }
};

class LigarBombaB : public Comando {
public:
    string executar(EstacaoBombeamento& e) override {
        e.getBombas()[1].ligar();
        return "P-101B ligada";
    }
    string nome() const override { return "LIGAR_BOMBA_B"; }
};

class ResetarBloqueios : public Comando {
public:
    string executar(EstacaoBombeamento& e) override {
        for (auto& b : e.getBombas()) b.desbloquear();
        return "bloqueios removidos";
    }
    string nome() const override { return "RESETAR_BLOQUEIOS"; }
};

// -------------------------------------------------------
// Repositorio - padrao Repository
// Isola a gravacao em arquivo do restante do sistema.
// Se precisar trocar para TCP ou SQLite, so muda aqui.
// -------------------------------------------------------
class RepositorioJsonLines {
private:
    string caminho;

public:
    explicit RepositorioJsonLines(string c) : caminho(c) {}

    void salvar(const string& linha) {
        ofstream arq(caminho, ios::app);
        if (!arq.is_open())
            throw runtime_error("nao foi possivel abrir: " + caminho);
        arq << linha << "\n";
    }
};

// -------------------------------------------------------
// Factory de sensores - padrao Factory
// Ponto unico de criacao. Util se sensor vier de config
// externa no futuro (ex: arquivo JSON de configuracao).
// -------------------------------------------------------
class FabricaSensores {
public:
    static unique_ptr<Sensor> criar(const string& t) {
        if (t == "nivel")             return make_unique<SensorNivel>();
        if (t == "pressao")           return make_unique<SensorPressao>();
        if (t == "vazao")             return make_unique<SensorVazao>();
        if (t == "temperatura_motor") return make_unique<SensorTemperaturaMotor>();
        throw invalid_argument("tipo de sensor invalido: " + t);
    }
};

// -------------------------------------------------------
// main
// -------------------------------------------------------
int main() {
    try {
        EstacaoBombeamento estacao;
        RepositorioJsonLines repo("../../data/leituras.jsonl");

        // regras aplicadas em ordem a cada ciclo (Strategy)
        vector<unique_ptr<RegraControle>> regras;
        regras.push_back(make_unique<RegraNivel>());
        regras.push_back(make_unique<RegraPressao>());
        regras.push_back(make_unique<RegraVazaoBaixa>());
        regras.push_back(make_unique<RegraSensorTravado>());
        regras.push_back(make_unique<RegraBloqueioPorMotor>());

        cout << "[EB-13] dispositivo iniciado. gravando em data/leituras.jsonl\n";

        for (int i = 0; i < 80; ++i) {
            estacao.atualizarSensores();
            for (auto& r : regras) r->aplicar(estacao);

            string pacote = estacao.pacoteJson();
            repo.salvar(pacote);
            cout << pacote << "\n";

            this_thread::sleep_for(chrono::milliseconds(350));
        }

        cout << "[EB-13] simulacao encerrada.\n";
        return 0;

    } catch (const exception& ex) {
        cerr << "[EB-13] erro: " << ex.what() << "\n";
        return 1;
    }
}
